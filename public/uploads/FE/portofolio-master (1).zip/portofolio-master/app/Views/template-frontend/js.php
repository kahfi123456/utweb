<script src="/assets/cv/common-js/jquery-3.2.1.min.js"></script>

<script src="/assets/cv/common-js/tether.min.js"></script>

<script src="/assets/cv/common-js/bootstrap.js"></script>

<script src="/assets/cv/common-js/isotope.pkgd.min.js"></script>

<script src="/assets/cv/common-js/jquery.waypoints.min.js"></script>

<script src="/assets/cv/common-js/progressbar.min.js"></script>

<script src="/assets/cv/common-js/jquery.fluidbox.min.js"></script>

<script src="/assets/cv/common-js/scripts.js"></script>