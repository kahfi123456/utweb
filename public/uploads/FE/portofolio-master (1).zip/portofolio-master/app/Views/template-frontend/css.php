<!-- Font -->

<link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600,700%7CAllura" rel="stylesheet">

<!-- Stylesheets -->

<link href="/assets/cv/common-css/bootstrap.css" rel="stylesheet">
<link href="/assets/cv/common-css/ionicons.css" rel="stylesheet">
<link href="/assets/cv/common-css/fluidbox.min.css" rel="stylesheet">
<link href="/assets/cv/css/styles.css" rel="stylesheet">
<link href="/assets/cv/css/responsive.css" rel="stylesheet">