<!DOCTYPE HTML>
<html lang="en">

<head>
    <title>Portofolio</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">
    <?= $this->include('template-frontend/css'); ?>
</head>

<body>

    <?= $this->renderSection('content') ?>

    <?= $this->include('template-frontend/footer'); ?>

    <!-- SCIPTS -->
    <?= $this->include('template-frontend/js'); ?>

</body>

</html>