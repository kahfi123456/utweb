<meta name="<?= csrf_token() ?>" id="<?= csrf_token() ?>" content="<?= csrf_hash() ?>">
<!-- Favicon -->
<link rel="icon" href="/assets/argon/img/brand/favicon.png" type="image/png">
<!-- Fonts -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">
<!-- Icons -->
<link rel="stylesheet" href="/assets/argon/js/components/nucleo/css/nucleo.css" type="text/css">
<link rel="stylesheet" href="/assets/argon/js/components/fontawesome-free/css/all.min.css" type="text/css">
<!-- Page plugins -->
<!-- Toastr -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" type="text/css">
<!-- Argon CSS -->
<link rel="stylesheet" href="/assets/argon/css/argon.css?v=1.2.0" type="text/css">